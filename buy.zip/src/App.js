import React, { useState } from 'react';
import './App.css';
import AddProducts from './Component/Products/AddProducts';
import ProductsList from './Component/Products/ProductsList'
function App() {
  const [ProductsLists, setProductsList] = useState([])
  const OnHandlerProductsListAdd = (Product, prize,stock) => {
    setProductsList((prevState) => {
      return [
        ...prevState,
        { Product: Product, prize: prize,id:Math.random().toString(),stock:stock }
      ]
    })
  }

  return (
    <div>
      <AddProducts OnProductListAdd={OnHandlerProductsListAdd} />
      <ProductsList Products={ProductsLists} />
    </div>
  );
}

export default App;
