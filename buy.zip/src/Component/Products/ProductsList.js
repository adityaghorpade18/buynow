import React from "react";
import Card from '../UI/Card';
import classes from './ProductsList.module.css'
const ProductsList = (props) => {
    return (
        <Card className={classes.users}>
            <ul>
                {props.Products.map((user) => {
                  return  <li key={user.id}>
                        {user.Product} ({user.stock}) {user.prize}
                    </li>
                })}
            </ul>
        </Card>
    );
}
export default ProductsList;