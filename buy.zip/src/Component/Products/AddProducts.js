import React, { useState } from "react";
import Card from "../UI/Card";
import Classes from "./AddProducts.module.css";
import Button from "../UI/Button";
import ErrorModel from "./ErrorModel";
const AddProductsList = (props) => {
  const [enteredProductname, setEnteredProductname] = useState("");
  const [enteredProductStock, setEnteredProductStock] = useState("");
  const [enteredProductPrice, setEnteredProductPrice] = useState("");

  const [error, setError] = useState();
  const addUserHandler = (event) => {
    event.preventDefault();
    if (
      enteredProductname.trim().length === 0 ||
      enteredProductStock.trim().length === 0||
      enteredProductPrice.trim().length === 0 

    ) {
      setError({
        title: "Invalid input",
        message: "Please enter valid name and age (non-empty values).",
      });
      return;
    }
    if (+enteredProductStock < 1) {
      setError({
        title: "Invalid age",
        message: "Please enter valid age grater than zero",
      });
      return;
    }
    if (+enteredProductPrice < 1) {
      setError({
        title: "Invalid Price",
        message: "Please enter valid Price grater than zero",
      });
      return;
    }
    
    props.OnProductListAdd(enteredProductname, enteredProductStock,enteredProductStock);
 
    setEnteredProductname("");
    setEnteredProductStock("");
    setEnteredProductPrice("")
  };
  const usernameChangeHandler = (event) => {
    setEnteredProductname(event.target.value);
  };
  const userageChangeHandler = (event) => {
    setEnteredProductStock(event.target.value);
  };
  const userageChangeHandlerPrice=(event)=>{
    setEnteredProductPrice(event.target.value)
  }
  const setErrorHandler = () => {
    setError(null);
  };
  return (
    <div>
      {error && (
        <ErrorModel
          title={error.title}
          OnErrorClean={setErrorHandler}
          message={error.message}
        />
      )}

      <Card className={Classes.input}>
        <form onSubmit={addUserHandler}>
          <label htmlFor="product">Product</label>
          <input
            id="product"
            type="text"
            value={enteredProductname}
            onChange={usernameChangeHandler}
          />

          <label htmlFor="Stock">Stock</label>
          <input
            id="Stock"
            type="number"
            value={enteredProductStock}
            onChange={userageChangeHandler}
          />

        <label htmlFor="Stock">Price</label>
          <input
            id="price"
            type="number"
            value={enteredProductPrice}
            onChange={userageChangeHandlerPrice}
          />
          <Button type="submit">Add Product</Button>
        </form>
      </Card>
    </div>
  );
};

export default AddProductsList;
